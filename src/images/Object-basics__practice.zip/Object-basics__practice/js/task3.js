'use strict';

document.querySelector('.title').innerText = 'Task 3';

/*

Задание 3: Restore names

  В базе данных пользователей произошел сбой, и у некоторых пользователей исчезли значения поля firstName. Хорошо что в user уже есть поле fullName, из которого мы можем взять нужные данные.

  Реализуй функцию restoreNames, которая принимает массив объектов users и меняет поле firstName пользователям, у которых оно отсутствует или равно undefined, опираясь на значение поля fullName. Функция ничего не возвращает.

Пример:

  const users = [
    {
      firstName: undefined,
      lastName: 'Holy',
      fullName: 'Jack Holy',
    },
    {
      lastName: 'Adams',
      fullName: 'Mike Adams',
    },
  ];

  restoreNames(users);

  users === [
    {
      firstName: 'Jack',
      lastName: 'Holy',
      fullName: 'Jack Holy',
    },
    {
      firstName: 'Mike',
      lastName: 'Adams',
      fullName: 'Mike Adams',
    },
  ];

Подсказка
  Используй метод split чтобы разделить fullName на два слова и возьми первое из этих слов для firstName

*/

function restoreNames(users) {
  // insert your code here
}

console.log(
  // restoreNames(users),
);
