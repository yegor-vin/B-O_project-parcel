'use strict';

const NUMBER_OF_TASKS = 9;
let CURRENT_TASK_NUMBER = JSON.parse(localStorage.getItem('task'));

const tasks = document.querySelector('.tasks');

function createButtons() {
  for (let i = 1; i <= NUMBER_OF_TASKS; i++) {
    const button = document.createElement('button');
    button.className = 'task';
    button.textContent = `Task ${i}`;

    button.addEventListener('click', () => {
      CURRENT_TASK_NUMBER = i;

      localStorage.setItem('task', JSON.stringify(CURRENT_TASK_NUMBER));

      render();
      updateActiveTask();
    });

    tasks.append(button);
  }
}

function render() {
  const scriptsOnPage = document.querySelectorAll('script');
  scriptsOnPage.forEach((script) => script.remove());

  const updatedScript = document.createElement('script');
  updatedScript.src = `./js/task${CURRENT_TASK_NUMBER}.js`;

  tasks.after(updatedScript);
}

function updateActiveTask() {
  const tasks = document.querySelectorAll('.task');

  tasks.forEach((task) => task.classList.remove('active'));

  tasks.forEach((task, i) => {
    if (i + 1 === CURRENT_TASK_NUMBER) {
      task.classList.add('active');
    }
  });
}

createButtons();
render();
updateActiveTask();
