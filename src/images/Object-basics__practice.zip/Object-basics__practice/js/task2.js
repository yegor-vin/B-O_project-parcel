'use strict';

document.querySelector('.title').innerText = 'Task 2';

/*

Задание 2: Add full name

  База данных хранит пользователей в формате:

  {
    firstName: 'Ivan',
    lastName: 'Vasylchenko',
  }

  Было бы удобно добавить поле fullName в каждый объект.

  Создай функцию addFullName, которая принимает объект user и добавляет ему свойство fullName со значением - именем и фамилией, разделёнными одним пробелом.

  Возвращать из функции ничего не нужно!

Пример:

  const user = {
    firstName: 'Ivan',
    lastName: 'Vasylchenko',
  };

  addFullName(user);

  user === {
    firstName: 'Ivan',
    lastName: 'Vasylchenko',
    fullName: 'Ivan Vasylchenko',
  }

*/

function addFullName(user) {
  // insert your code here
}

console.log(
  // addFullName(user),
);
