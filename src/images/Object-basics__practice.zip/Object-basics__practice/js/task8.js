'use strict';

document.querySelector('.title').innerText = 'Task 8';

/*

Задание 8: Get robot schema

  Ночью у главного инженера кто-то стащил со стола чертежи. Теперь мы не знаем, какие данные нужны, чтобы робот работал корректно. Предлагаю поймать одного робота, который сейчас убирает в коридоре, подключиться к его терминалу и узнать, какие поля нам нужны для новых роботов.

  Создай функцию getRobotSchema, которая принимает объект robot и возвращает его схему — объект с теми же ключами, что и у robot, и типами данных в качестве значений.

Пример:

  const robot = {
    version: 16,
    name: 'Cleaner 3000',
    released: true,
    creator: { name: 'Vlad' },
  };

  getRobotSchema(robot) === {
    version: 'number',
    name: 'string',
    released: 'boolean',
    author: 'object',
  }

*/

function getRobotSchema(robot) {
  // insert your code here
}

console.log(
  // getRobotSchema(robot),
);
