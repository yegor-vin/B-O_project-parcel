'use strict';

document.querySelector('.title').innerText = 'Task 1';

/*

Задание 1: Warehouse objects

  На складе компьютерных деталей Mate warehouse есть коробки с различными видами запчастей.
  В каждой коробке лежит деталь, соответствующая названию коробки.
  К примеру в коробке memory лежит оперативная память, в коробке processors лежат процессоры и так далее.
  Кладовщику нужно знать где что хранится.

  Создай объект warehouse, в котором будут свойства (коробки), соответствующие трем типам деталей
  (memory, processors, displays).

  Сейчас у нас на складе 10 процессоров, 20 дисплеев и 15 планок оперативной памяти.

*/

const inputCode = document.createElement('textarea');
document.body.append(inputCode);
inputCode.style.resize = 'none';

const warehouse = {};

console.log();
