'use strict';

document.querySelector('.title').innerText = 'Task 4';

/*

Задание 4: Remove female ages

  У нас больше нет необходимости хранить данные о возрасте наших пользователей, поэтому мы решили удалить возраст из базы в два этапа.

  Нужно удалить поле age из базы данных people для всех, у кого gender равен female. Возвращать из функции ничего не нужно.

Пример:

  const people = [
    { name: 'Emma', gender: 'female', age: 19 },
    { name: 'Avram', gender: 'male', age: 41 },
  ];

  Удаляем возраст у тех людей, у кого поле 'gender'
  имеет значение 'female' и получаем:

  const people = [
    { name: 'Emma', gender: 'female' },
    { name: 'Avram', gender: 'male', age: 41 },
  ];

*/

function removeFemaleAges(people) {
  // insert your code here
}

console.log(
  // removeFemaleAges(people),
);
