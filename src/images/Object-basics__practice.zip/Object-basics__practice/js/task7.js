'use strict';

document.querySelector('.title').innerText = 'Task 7';

/*

Задание 7: Count boxes

  На складах порядок. Роботы стоят без работы. Проведем инвентаризацию?

  На каждой коробке есть 1 символ обозначающий её тип. Нужно научить роботов различать и считать их.

  Создай функцию countBoxes, которая принимает строку boxes, в которой каждый символ это тип одной из коробок на складе. Посчитай, сколько коробок каждого типа есть на складе, и верни объект с отчётом.

Пример:

  countBoxes('aabca') === { a: 3, b: 1, c: 1 }
  countBoxes('aaaaca31') === { a: 5, c: 1, 3: 1, 1: 1 }
  countBoxes('') === {}

*/

function countBoxes(string) {
  // insert your code here
}

console.log(
  // countBoxes(string),
);
