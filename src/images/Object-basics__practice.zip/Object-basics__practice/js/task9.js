'use strict';

document.querySelector('.title').innerText = 'Task 9';

/*

Задание 9: Are robots the same

  Mate Robot Factory уже выпустила не одну сотню роботов различных конфигураций, размеров и видов. Информация о каждом роботе хранится в виде объекта с его характеристиками.

  Давай напишем функцию compareRobots, которая принимает двух роботов и возвращает true, только если все характеристики обоих роботов совпадают (порядок свойств значения не имеет, только ключи и значения).

Примечания:

  - У каждого робота есть уникальный серийный номер (не учитываем при сравнении)
  - Свойства роботов не могут иметь значения undefined и NaN.

Примеры:

  const charlie = { serialNo: 1, chipVer: 12 };

  const lordy = { serialNo: 2, chipVer: 12 };
  compareRobots(charlie, lordy); // true

  const paul = { serialNo: 3, chipVer: 15 };
  compareRobots(paul, charlie); // false

  const mike = { serialNo: 4, chipVer: 12, wheels: 1 };
  compareRobots(mike, charlie); // false

  const max = { serialNo: 5, engineVer: 12 };
  compareRobots(max, charlie); // false

  const steve = { serialNo: 6 };
  compareRobots(steve, charlie); // false

*/

function compareRobots(robot1, robot2) {
  // insert your code here
}

console.log(
  // compareRobots(robot1, robot2),
);
